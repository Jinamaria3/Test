﻿namespace DemoHospital.Models
{
    public class Patient
    {

        public string PatientId { get; set; } = null!;
        public DateTime? DateOfBirth { get; set; }
        public string? Sex { get; set; }
        public string? HospitalId { get; set; }
        public string? Postcode { get; set; }
        public DateTime? AdmitDate { get; set; }
        public DateTime? DischargeDate { get; set; }
    }
}
