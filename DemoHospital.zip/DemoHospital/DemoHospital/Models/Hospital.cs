﻿namespace DemoHospital.Models
{
    public class Hospital
    {
        public string HospitalId { get; set; } = null!;
        public string? HospitalName { get; set; }
        public string? Postcode { get; set; }
        public string? Area { get; set; }
    }
}
