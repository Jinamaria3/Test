﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace DemoHospital.Models
{
    public class PatientViewModel
    {
       
            public List<Patient>? Patients { get; set; }
            public SelectList? hospitalids { get; set; }
            public string? Hospitalid { get; set; }
            public string? admittedstatus { get; set; }
            public string? Age { get; set; }

    }
}
