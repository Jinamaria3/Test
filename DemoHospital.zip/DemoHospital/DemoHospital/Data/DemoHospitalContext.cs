﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DemoHospital.Models;

namespace DemoHospital.Data
{
    public class DemoHospitalContext : DbContext
    {
        public DemoHospitalContext (DbContextOptions<DemoHospitalContext> options)
            : base(options)
        {
        }

        public DbSet<DemoHospital.Models.Patient> Patient { get; set; } = default!;
    }
}
